function [C1,A0] = SNTD(Y,Omega,Nway,Nrank,opts)

%% Sparse Nonnegative Tucker Decomposition and Completion

%% Parameters and defaults
if isfield(opts,'maxit')  maxit = opts.maxit;    end
if isfield(opts,'tol')    tol = opts.tol;        end
if isfield(opts,'alpha')  alpha = opts.alpha;    end
if isfield(opts,'rho')    rho = opts.rho;        end
if isfield(opts,'beta1')  beta1 = opts.beta1;    end
if isfield(opts,'beta2')  beta2 = opts.beta2;    end
if isfield(opts,'beta3')  beta3 = opts.beta3;    end
if isfield(opts,'a')      a = opts.a;      end
if isfield(opts,'c')      c = opts.c;      end
if isfield(opts,'sigma')  sigma = opts.sigma;    end
if isfield(opts,'lambda') lambda = opts.lambda;  end
if isfield(opts,'hosvd')  hosvd = opts.hosvd;    end

%%
II1 = eye(prod(Nrank));
d = length(Nway);

H0 = cell(1,d);
S0 = cell(1,d);
M0 = cell(1,d);
N0 = cell(1,d);
%% Initial value
if isfield(opts,'A0')
    A0 = opts.A0;
else
    A0 = cell(1,d);
    for n = 1:d
        % randomly generate each factor matrix
        A0{n} = min(max(0,randn(Nway(n),Nrank(n))),a{n});
        H0{n} = A0{n};
        S0{n} = A0{n};
        M0{n} = A0{n};
        N0{n} = A0{n};
    end
end

if isfield(opts,'C0')
    C0 = opts.C0;
else
    % randomly generate core tensor
    C0 = tensor(min(max(0,randn(Nrank)),1));
end


if hosvd
    for n = 1:d
        Atilde = ttm(tensor(Y), A0, -n, 't');
        A0{n} = max(eps,nvecs(Atilde,n,Nrank(n)));
    end
    A0 = cellfun(@(x) bsxfun(@rdivide,x,sum(x)),A0,'uni',0);
    C0 = ttm(tensor(Y), A0, 't');
end

B0 = C0;
Zk = Y;
Xk0 = Y;

ATA = cell(1,d); % A'*A
for n = 1:d        
    A0{n} = A0{n}/norm(A0{n},'fro');
    ATA{n} = A0{n}'*A0{n};
end

if isfield(opts,'T1')   T1 = opts.T1;  else  T1 = tensor(randn(Nway));   end
if isfield(opts,'T2')   T2 = opts.T2;  else  T2 = tensor(randn(Nway));   end
if isfield(opts,'T3')   T3 = opts.T3;  else  T3 = tensor(randn(Nrank));   end
%%

for k = 1:maxit
    %% Compute X^{k+1}
    SS = (beta1*ttm(C0, A0) - T1 + beta2*Zk - T2)/(beta1 + beta2);
      Xk1 =  proxGauss(Y, SS, Omega, beta1+beta2, sigma); %% Gaussian
 % Xk1 =  proxLaplace(Y, SS , Omega, beta1+beta2, sigma); %% Laplace
%      Xk1 = proxPoisson(Y, SS, Omega, beta1+beta2);  %% Poisson noise
    
    %% Compute the core tensor C^{k+1}
    ATA1 =  A0{d}'*A0{d};
    for i = d-1:-1:1
        KATA = kron(ATA1,A0{i}'*A0{i});
        ATA1 = KATA;
    end
    qk = ttm(beta1*Xk1 + T1, A0,'t') + beta3*B0 - T3;
    C1 = inv(beta1*KATA + beta2*II1)*qk(:);
    C1 = tensor(reshape(C1,Nrank));
    
    %% Compute factor matrices Ai
    for i = 1:d
        A0{i} = eye(Nrank(i));
        Rk = ttm(C1,A0);
        Rk = tenmat(Rk,i);
        Rk = Rk.data;
        Rgh = inv(beta1*Rk*Rk' + rho{i}*eye(Nrank(i)));
        RH = tenmat(beta1*Xk1 + T1,i);
        RH = RH.data;
        A0{i} = (RH*Rk' + rho{i}*H0{i} - M0{i})*Rgh;
    end
    
    %% Compute Z^{k+1}
    Zk = projection(Xk1.data + T2.data/beta2,0,c);
    
    %% Compute B^{k+1}
    B0 = projection(C1.data + T3.data/beta3,0,1);
    
    %% Compute H_i{k+1}, S_i^{k+1}
   parfor i = 1:d
      H0{i} = proxl0(A0{i} + M0{i}/rho{i}, lambda{i}/rho{i}); 
      S0{i} = projection(A0{i} + N0{i}/alpha{i},0,a{i});
   end
   
   %% Update the multipliers T_i^{k+1}, M_i^{k+1}, N_i{k+1}
   TDC = ttm(C1, A0);
   T1 = T1 + beta1*(Xk1 - TDC);
   T2 = T2 + beta2*(Xk1 - Zk);
   T3 = T3 + beta3*(C1 - B0);
   parfor i = 1:d
       M0{i} = M0{i} + rho{i}*(A0{i} - H0{i});
       N0{i} = N0{i} + alpha{i}*(A0{i} - S0{i});
   end
   
   %% stopping criterion
   rela = norm(Xk1(:) - Xk0(:))/norm(Xk0(:));
   if rela <= tol
       break;
   end
   
   %%
   
   C0 = C1;
   Xk0 = Xk1;
   
end

end



