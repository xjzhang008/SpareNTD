function X = projection(Y,a,b)
%% projection onto a set [a b]
%%
X = Y;
X(Y<a) = a;
X(Y>b) = b;

end