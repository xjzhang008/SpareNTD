%% proximal mapping for Gaussian noise

function X = proxGauss(Y, S, Omega, rho, sigma)
         Nway = size(Y);
         X = ((Y + rho*sigma^2*S)/(1+rho*sigma^2)).*Omega + (ones(Nway) - Omega).*S;      
end