function X = proxLaplace(Y, S, Omega, rho, tau)
%% Proximal mapping of Lapace noise
n = size(Y);
X = Y.*Omega + (sign(S.data - (Y.data).*Omega).*max(abs(S.data - (Y.data).*Omega) - 1/(rho*tau),0)).*Omega + (ones(n) - Omega).*S;

end