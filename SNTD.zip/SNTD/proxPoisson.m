function X = proxPoisson(Y, S, Omega, rho)
%% proximal mapping for Poisson observations
% [n1 n2 n3] = size(Y);
II = ones(size(Y));
X = ((rho.*S - II + sqrt((rho.*(S.data) - II).^2 + 4*rho.*(Y.data)))./(2*rho)).*Omega + (II - Omega).*S;
end