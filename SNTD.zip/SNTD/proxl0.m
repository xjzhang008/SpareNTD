function X = proxl0(Y,lambda)
%% proximal mapping of L0 norm
%%
X = Y;
index1 = find(abs(Y) <= sqrt(2*lambda));
X(index1) = 0;

end